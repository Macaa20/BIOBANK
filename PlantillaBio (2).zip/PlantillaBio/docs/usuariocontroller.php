<?php
    require_once 'conexion.php';
    class Usuario{
        protected $con, $email, $nombre, $clave;
 
        public function __construct()
		{
			$this->con = Database::connect();
		}

        public function Login($email){
            $sql = "SELECT u.EmailUsuario AS email , u.Clave AS contra, r.Rol FROM Usuario u INNER JOIN Rol r
            ON u.idRol=r.idRol WHERE u.EmailUsuario = '$email';";
            $res = mysqli_query($this->con, $sql);
            
            if($res){
                return $res;
            } else {
                return false;
            }
        }
        public function getclientes(){
            $sql = "SELECT * FROM Cliente;";
            $res = mysqli_query($this->con, $sql);
            
            if($res){
                return $res;
            } else {
                return false;
            }
        } 
    }

?>