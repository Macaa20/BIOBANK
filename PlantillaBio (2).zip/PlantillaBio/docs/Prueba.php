<?php
session_start();

if (!isset($_SESSION['info_usuario'])) {
    header('Location: ../index.php');
} else {
}


if($_SESSION['info_usuario']->Tipo == 1){
    header('Location: dashboard-Super-Administrador.html ');
} elseif($_SESSION['info_usuario']->Tipo == 2){
    header('Location: dashboard-Administrador.html');
} elseif($_SESSION['info_usuario']->Tipo == 3){
    header('Location: dash 3.html ');
} elseif($_SESSION['info_usuario']->Tipo == 4){
    header('Location: dash 4.html ');
}
?>