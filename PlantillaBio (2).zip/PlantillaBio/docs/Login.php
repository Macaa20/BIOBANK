<?php

require_once 'usuariocontroller.php';

if(isset($_POST["Ingresar"])){
    $Usu = $_POST["usu"];
    $Contraseña = $_POST["pass"];

    $Usuario = new Usuario();
    
    $res = $Usuario->Login($Usu);

    $lista = mysqli_fetch_object($res);
    
    if($Contraseña == $lista->contra){
        if($Usu == $lista->email){
            session_start();
            $_SESSION['info_usuario'] = $lista;
            header('Location: dashusuarios.php ');
        }
    }
}

?>