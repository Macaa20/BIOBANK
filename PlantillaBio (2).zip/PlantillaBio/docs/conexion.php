<?php

class Database{
    public $db;
    public static function connect(){
        $servername ="88.218.93.101";
        $database = "pruebas";
        $username = "root";
        $password = "1Plu$2018-2019";
        
        $db = new mysqli($servername, $username, $password, $database);
        $db->query("SET NAMES 'utf8'");
        return $db;
    }
}


// Check connection
/*if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully";*/


?>