import 'select2/dist/js/select2.min.js'

$.fn.select2.defaults.set( "theme", "bootstrap4" );
