$(document).ready(function() {
  $('.splash').removeClass('active');
});
