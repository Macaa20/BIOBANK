import quill from 'script-loader!quill/dist/quill.js'
