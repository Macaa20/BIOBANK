import moment from 'moment'
window.moment = moment
