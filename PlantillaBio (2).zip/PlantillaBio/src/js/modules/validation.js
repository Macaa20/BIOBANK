import 'jquery-validation'
import "jquery-validation/dist/additional-methods.js"
