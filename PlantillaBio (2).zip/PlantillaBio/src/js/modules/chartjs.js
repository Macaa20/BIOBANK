import Chart from 'chart.js';

Chart.defaults.global.defaultFontFamily = "'Hind Vadodara', 'Helvetica Neue', 'Helvetica', 'Arial', sans-serif";

window.Chart = Chart;
